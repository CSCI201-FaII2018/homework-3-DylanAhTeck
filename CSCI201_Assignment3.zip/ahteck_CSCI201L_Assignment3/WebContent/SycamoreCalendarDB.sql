DROP DATABASE IF EXISTS SycamoreDatabase;
CREATE DATABASE IF NOT EXISTS SycamoreDatabase;
USE SycamoreDatabase;

--
-- Table structure for table `UserAccounts`
--

-- DROP TABLE IF EXISTS `UserAccounts`;

CREATE TABLE IF NOT EXISTS `UserAccounts` (
  UserId          INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  idTokenString TEXT NOT NULL,
  googleIDString varchar(50) NOT NULL,
  accessTokenString TEXT NOT NULL,
  imgURLString TEXT NOT NULL, 
  `name` varchar(50) NOT NULL
);
-- UserAccounts
--
-- Table structure for table `Friendship`
--

CREATE TABLE IF NOT EXISTS Friendship ( -- Stands for an associative entity type.
    RequesterId     INT      NOT NULL,
    AddresseeId     INT      NOT NULL, -- Fixed with a well-delimited data type.
    CreatedDateTime DATETIME NOT NULL,
    
    --
    CONSTRAINT Friendship_PK            PRIMARY KEY (RequesterId, AddresseeId), -- Composite PRIMARY KEY.
    CONSTRAINT FriendshipToRequester_FK FOREIGN KEY (RequesterId) REFERENCES UserAccounts (UserId),
    CONSTRAINT FriendshipToAddressee_FK FOREIGN KEY (AddresseeId) REFERENCES UserAccounts (UserId),
    CONSTRAINT FriendsAreDifferent_CK   CHECK       (RequesterId <> AddresseeId) -- Unfortunately, at the time of writing, this constraint would not be enforced by MySQL.
);

CREATE TABLE IF NOT EXISTS UserEvents (
	eventID INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    title TEXT NOT NULL,
    sTime TEXT NOT NULL,
    sDate TEXT NOT NULL,
    googleIDString TEXT NOT NULL,
    eventNUM INT 
   -- FOREIGN KEY UserLink_fk (eventID) REFERENCES UserAccounts(UserId)
);