DROP DATABASE IF EXISTS SycamoreDatabase;
CREATE DATABASE IF NOT EXISTS SycamoreDatabase;
USE SycamoreDatabase;

--
-- Table structure for table `UserAccounts`
--

-- DROP TABLE IF EXISTS `UserAccounts`;

CREATE TABLE IF NOT EXISTS `UserAccounts` (
  UserId          INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  idTokenString TEXT NOT NULL,
  googleIDString varchar(50) NOT NULL,
  accessTokenString TEXT NOT NULL,
  imgURLString TEXT NOT NULL, 
  username varchar(50) NOT NULL
);
-- UserAccounts
--
-- Table structure for table `Friendship`

CREATE TABLE Friends(

	relationID INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    myUserID varchar(50) NOT NULL,
    friendID varchar(50) NOT NULL
   -- FOREIGN KEY (myUserID) REFERENCES UserAccounts(googleIDString)
);


CREATE TABLE IF NOT EXISTS UserEvents (
	eventID INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    title TEXT NOT NULL,
    sTime TEXT NOT NULL,
    sDate TEXT NOT NULL,
    googleIDString TEXT NOT NULL,
	
    eventNUM INT 
   -- FOREIGN KEY UserLink_fk (eventID) REFERENCES UserAccounts(UserId)
);