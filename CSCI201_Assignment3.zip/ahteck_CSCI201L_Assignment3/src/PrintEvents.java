

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;


/**
 * Servlet implementation class PrintEvents
 */
@WebServlet(name = "PrintEvents") 
public class PrintEvents extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrintEvents() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		Calendar service = null;
	    HttpSession session = request.getSession(false);  
	  //False because we do not want it to create a new session if it does not exist.

	    
	      if(session != null){
	    	  
	          service = (Calendar) session.getAttribute("service");
	          System.out.println("SESSION EXISTS!! ");
	      }
		
	      else  System.out.print("NO SESSION ");
        // List the next 10 events from the primary calendar.
        DateTime now = new DateTime(System.currentTimeMillis());
        Events events = service.events().list("primary")
                .setMaxResults(10)
                .setTimeMin(now)
                .setOrderBy("startTime")
                .setSingleEvents(true)
                .execute();
        List<Event> eventItems = events.getItems();
        
        //Create list of the required table columnn values
        List<String> title = new ArrayList<String>();
        List<String> StartDate = new ArrayList<String>();
        List<String> StartTime = new ArrayList<String>();
        System.out.println("Middle");
        for(int i = 0; i < eventItems.size(); i++)
        {
        	title.add(eventItems.get(i).getSummary());
        	DateTime start = eventItems.get(i).getStart().getDateTime();
            if (start == null) {
                start = eventItems.get(i).getStart().getDate();
            }
            String str = start.toString(); 
            String[] DateTime = str.split("T", 2); 
            
            //Parse date into correct format
            String[] parse_date = DateTime[0].split("-", 3);
            String month = parse_date[1];
            int monthInt = Integer.valueOf(month);  
		    month = getMonthForInt(monthInt);
            
		    //Parse time into correct format 
		    String time = DateTime[1];
		    time = time.substring(0, 5);
		    
		   
		    DateFormat f1 = new SimpleDateFormat("HH:mm"); //HH for hour of the day (0 - 23)
		    Date d = null;
		    try {
				d = f1.parse(time);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		    DateFormat f2 = new SimpleDateFormat("h:mma");
		    time = f2.format(d);
		  
            StartDate.add(month + " " + parse_date[2] + ", " + parse_date[0]);
            StartTime.add(time);
        }
        
        
     
       
        //Send to profile page
        session.setAttribute("title", title);
        session.setAttribute("date", StartDate);
        session.setAttribute("time", StartTime);
        
        System.out.println("Print Events Terminates");
		
		
	}
	
	//Helper function to return month string 
	private static String getMonthForInt(int m) {
		m = m-1;
		
	    String month = "invalid";
	    DateFormatSymbols dfs = new DateFormatSymbols();
	    String[] months = dfs.getMonths();
	    if (m >= 0 && m <= 11 ) {
	        month = months[m];
	    }
	    return month;
	}
	
	
}
