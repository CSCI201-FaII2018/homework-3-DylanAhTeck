
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ahteck_CSCI201L_Assignment3.User;

/**
 * Servlet implementation class CheckFollowing
 */
@WebServlet("/Following")
public class Following extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Following() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		
		String googleIDString = (String)session.getAttribute("googleIDString");
		String followID = request.getParameter("follow");
		
		ArrayList<Integer> following = new ArrayList<Integer>();
		
		String driverClassName = "com.mysql.jdbc.Driver";
   		String dbURL = "jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
   		Connection conn = null; //create the connection to database
		Statement st = null; //executes any sql command
		PreparedStatement ps = null;
		ResultSet rs = null; //retrieve data that comes back (from select statement), a table
		
		
   		try {
   	   		
   			Class.forName(driverClassName);
   			conn = DriverManager.getConnection(dbURL);
   			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Friends;");
			
			
			ArrayList<String> returnUsers = new ArrayList<String>();
	   		ArrayList<String> returnURLs = new ArrayList<String>();
	   		
	   		
	   		String add = request.getParameter("add");
	   		if(add.equals("yes"))
	   		{
	   			String query = "INSERT into Friends (myUserID, friendID)" + " values (?, ?)";

   	   			// create the mysql insert preparedstatement
   	   			ps = conn.prepareStatement(query);
   	   			ps.setString(1, googleIDString);
   	   			ps.setString(2, followID);

   	   			// execute the preparedstatement
   	   			ps.execute();

	   		}
	   		
	   		else if (add.equals("no")){
	   			String query = "DELETE FROM Friends WHERE myUserID = ? AND friendID = ?";
	   			ps = conn.prepareStatement(query);
	   			ps.setString(1, googleIDString);
	   			ps.setString(2, followID);
	   			System.out.println("This is myUserID: " + googleIDString);
	   			System.out.println("DELETE REACHES HERE");
	   			ps.execute();
	   		}
	   		
	   		else if(add.equals("0"))
	   		{
	   			System.out.println("Loadup");
				while(rs.next()) {
					String user = rs.getString("myUserID");
					String friend = rs.getString("friendID");
					System.out.println("user: " + user);
					System.out.println("friend: " + friend);
					System.out.println("googleIDString: " + googleIDString);
					System.out.println("followID: " + followID);
					
					
					if(user.equals(googleIDString) && friend.equals(followID)) {
						System.out.println("Congrats!");
						response.setContentType("text/html");
					    request.setAttribute("status", "yes");
					    
					    ServletOutputStream sout = response.getOutputStream();
		   				sout.print("following");
		   				sout.close();
					    
					}
				}
	   		}
	   		
	        //String googleIDString = (String) session.getAttribute("googleIDString");
	         System.out.println("Trigger 1");
	       	ps = conn.prepareStatement("SELECT * FROM Friends WHERE myUserID = ?");
	       	ps.setString(1, googleIDString);
	       	
	        List<User> usersList = new ArrayList<User>();
	        
	 		ResultSet r = ps.executeQuery();
	 		
	 		while(r.next()) {
	 			System.out.println("Trigger 2");

	 			String follower = r.getString("friendID");
	 			
	 			ps = conn.prepareStatement("SELECT * FROM UserAccounts WHERE googleIDString = ?");
	 			ps.setString(1, follower);
	 			ResultSet rss = ps.executeQuery();
	 			
	 			if(rss.next()) {
	 	  			User user = new User();
	 	  			user.setName(rss.getString("username"));
	 	  			user.setImage(rss.getString("imgURLString"));
	 	  			System.out.println(rss.getString("username"));
	 	      		System.out.println(rss.getString("imgURLString"));
	 	  			usersList.add(user);
	 			}
	 	  		
	 		}
	 	

			session.setAttribute("usersList" , usersList);
				
   				RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/test.jsp");
   				
   	   	   		try {
   	   	   			dispatch.forward(request,response);
   	   	   		} catch (IOException e) {
   	   	   			// TODO Auto-generated catch block
   	   	   			e.printStackTrace();
   	   	   		} catch (ServletException e) {
   	   	   			// TODO Auto-generated catch block
   	   	   			e.printStackTrace();
   	   	   		}   				
		
   		} catch (SQLException sqle){
			System.out.println("CF sqle: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe){	
			System.out.println("CF cnfe: " + cnfe.getMessage());
		}finally {
			try {
				
				if(rs!=null) {
					rs.close();
				}
				if(st!=null) {
					st.close();
				}
				if(conn!=null) {
					conn.close();
				}
				
			}
			catch (SQLException sqle) {
				System.out.println("sqle closing streams: " + sqle.getMessage());
			}
		}
   		
	}

}
