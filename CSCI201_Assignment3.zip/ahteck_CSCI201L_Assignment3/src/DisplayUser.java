import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DisplayUser
 */
@WebServlet("/DisplayUser")
public class DisplayUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String next = "/test.jsp";
		
		String search = request.getParameter("searchcontent");
		
		String driverClassName = "com.mysql.jdbc.Driver";
   		String dbURL = "jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
   		Connection conn = null; //create the connection to database
		Statement st = null; //executes any sql command
		PreparedStatement ps = null;
		ResultSet rs = null; //retrieve data that comes back (from select statement), a table	

		HttpSession session = request.getSession(true);
		
		ArrayList<String> dates = new ArrayList<String>();
		ArrayList<String> times = new ArrayList<String>();
		ArrayList<String> sums = new ArrayList<String>();
		//ArrayList<String> endDs = new ArrayList<String>();
		//ArrayList<String> endTs = new ArrayList<String>();
		
		//CHANGE userID / googleStringID to STRINGS RATHER THAN FLOATS
		String userID = "";
		String imgURL = "";
		String name = "";
		
		System.out.print("first");
   		try {
   	   		
   			Class.forName(driverClassName);
   			conn = DriverManager.getConnection(dbURL);
   			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM UserAccounts;");
			
			System.out.print("before while");
			while(rs.next()) { //as long as there are more rows
				String user = rs.getString("username");
				System.out.print("this is user retrieved from database: " + user);
				System.out.println("THIS IS search: " + search);
				if(user.equals(search)) {
					System.out.println("1!");
					imgURL = rs.getString("imgURLString");
					name = rs.getString("username");
					userID = rs.getString("googleIDString");
					
					session.setAttribute("pic", imgURL);
   					session.setAttribute("user", name);
					
	   	   			Statement s = conn.createStatement();
	   	   		
	   	   			ResultSet r = s.executeQuery("SELECT * FROM UserEvents");
	   	   			
	   	   			while(r.next()) {
	   	   				
	   	   				
	   	   				String i = r.getString("googleIDString");
	   	   				
	   	   				if(i.equals(userID)) {
	   	   				System.out.println("2!");
	   	   					String date = r.getString("sDate");
	   	   					String time = r.getString("sTime");
	   	   					String sum = r.getString("title");
	   	   				
	   	   					dates.add(date);
	   	   					times.add(time);
	   	   					sums.add(sum);
	   	   				System.out.println("4!");
	   	   					//endDs.add(r.getString("endDate"));
	   	   					//endTs.add(r.getString("endTime"));
	   	   					
	   	   				}	   				
	   	   			}			
				}
			}
   			
   		} catch (SQLException sqle){
			System.out.println("SU sqle: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe){	
			System.out.println("SU cnfe: " + cnfe.getMessage());
		}finally {
			try {
				
				if(rs!=null) {
					rs.close();
				}
				if(st!=null) {
					st.close();
				}
				if(conn!=null) {
					conn.close();
				}
				
			}
			catch (SQLException sqle) {
				System.out.println("sqle closing streams: " + sqle.getMessage());
			}
		}
   		
   		session.setAttribute("dates", dates);
   		session.setAttribute("times", times);
   		//session.setAttribute("endDates", endDs);
   		//session.setAttribute("endTimes", endTs);
   		session.setAttribute("sums", sums);
   		session.setAttribute("userID", userID);
   		session.setAttribute("imgURL", imgURL);
   		session.setAttribute("name", name);
   		
   		
   		
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		
    	try {
    		dispatch.forward(request,response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}