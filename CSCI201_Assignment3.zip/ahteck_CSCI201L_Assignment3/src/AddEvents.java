

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;

/**
 * Servlet implementation class AddEvents
 */
@WebServlet("/AddEvents")
public class AddEvents extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEvents() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		String username = request.getParameter("user");
		String date = request.getParameter("date");
		String time = request.getParameter("time");
		String endD = request.getParameter("endD");
		String endT = request.getParameter("endT");
		String sum = request.getParameter("summary");
		String initial = request.getParameter("initial");
		String user = "";
		
		HttpSession session = request.getSession(true);
		
		String title = request.getParameter("summary");
    	String start_date = request.getParameter("date");
    	String end_date = request.getParameter("endD");
    	String start_time = request.getParameter("time");
    	String end_time = request.getParameter("endT");
    	
    	start_time = start_time.replace("A", " A").trim();
    	start_time = start_time.replace("P", " P").trim();
    	end_time = end_time.replace("A", " A").trim();
    	end_time = end_time.replace("P", " P").trim();
    	
		//ADD TO CALENDAR
		Event event = new Event()
    		    .setSummary(title);
    		    
		//String string = "January 2, 2010";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);
		LocalDate start_d = LocalDate.parse(start_date, formatter);
		LocalDate end_d = LocalDate.parse(end_date, formatter);
		
		System.out.println(start_d); // 2010-01-02
		System.out.println(end_d);
		
			SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
	       SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
	       Date start_t = null, end_t = null;
	       try {
			start_t = parseFormat.parse(start_time);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	       try {
			end_t = parseFormat.parse(end_time);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	       start_time = displayFormat.format(start_t);
	       end_time = displayFormat.format(end_t);
	       System.out.println(start_time);
	       System.out.println(end_time);
	       
		
    	    DateTime startDateTime = new DateTime(start_d + "T" + start_time + ":00-08:00");
    	    
    	    EventDateTime start = new EventDateTime()
        		    .setDateTime(startDateTime)
        		    .setTimeZone("America/Los_Angeles");
        		event.setStart(start);
        		
        	DateTime endDateTime = new DateTime(end_d + "T" + end_time + ":00-08:00");
        	//Reverse sign to re-convert
    		//DateTime endDateTime = new DateTime(end_d + "T" + end_time + ":00-07:00");
    		
    		EventDateTime end = new EventDateTime()
        		    .setDateTime(endDateTime)
        		    .setTimeZone("America/Los_Angeles");
        		event.setEnd(end);


    		String calendarId = "primary";

   		    
   		    Calendar service = null;
   		  
   		      if(session != null){
   		          service = (Calendar) session.getAttribute("service");
   		          System.out.println("service was received: " + service);
   		          
   		       event = service.events().insert(calendarId, event).execute();
   		       System.out.println("Event inserted!");
   		      }
   		      else System.out.println("Problem finding session!");
   		          
   		//ADD TO DATABASE
    	String driverClassName = "com.mysql.jdbc.Driver";
   		String dbURL = "jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
   		Connection conn = null; //create the connection to database
		Statement st = null; //executes any sql command
		PreparedStatement ps = null;
		ResultSet rs = null; //retrieve data that comes back (from select statement), a table	

   		try {
   	   		
   			Class.forName(driverClassName);
   			conn = DriverManager.getConnection(dbURL);
   			st = conn.createStatement();
   			ResultSet rs1 = st.executeQuery("SELECT * FROM UserAccounts");
   			
   			while(rs1.next()) {
   				if(rs1.getString("username").equals(username)) {
   					user = rs1.getString("googleIDString");
   				}
   			}
   			/*
			rs = st.executeQuery("SELECT * FROM UserEvents;");
			
			boolean add = true;
			
			while(rs.next()) { //as long as there are more rows
				float userID = rs.getFloat("googleIDString");
				String startDate = rs.getString("sDate");
				String startTime = rs.getString("sTime");
				String eventSum = rs.getString("title");
				
				
				if(user==userID && date.equals(startDate) && time.equals(startTime) && sum.equals(eventSum)) {
					add = false; // don't add into the database
					
				}
	
			}
			*/
			
   			//if(add) {
   				
	            
   				String query = "INSERT into UserEvents  (title, sDate, sTime, googleIDString, eventNUM) values(?,?,?,?,?)";
   	   			// create the mysql insert preparedstatement
   	   			ps = conn.prepareStatement(query);
   	   			ps.setString(1, sum);
   	   			ps.setString(2, date);
   	   			ps.setString(3, time);
   	   			
   	   		//	ps.setString(4, user);
   	   			System.out.print("This is username on L100: " + username);
   	   			ps.setString(4, username);
   	   			ps.setInt(5, 0);
   	   		
   	   			
   	   			// execute the preparedstatement
   	   			ps.execute();
   			//}
   	   			
   	   		if(initial.equals("false")) {
   	   			
   	   			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Profile_Page.jsp");
   	   			
   	   	    	try {
   	   	    		dispatch.forward(request,response);
   	   			} catch (IOException e) {
   	   				// TODO Auto-generated catch block
   	   				e.printStackTrace();
   	   			} catch (ServletException e) {
   	   				// TODO Auto-generated catch block
   	   				e.printStackTrace();
   	   			}
   	   			
   			}
   			
   			
   		} catch (SQLException sqle){
			System.out.println("AE sqle: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe){	
			System.out.println("AE cnfe: " + cnfe.getMessage());
		}finally {
			try {
				
				if(rs!=null) {
					rs.close();
				}
				if(st!=null) {
					st.close();
				}
				if(conn!=null) {
					conn.close();
				}
				
			}
			catch (SQLException sqle) {
				System.out.println("sqle closing streams: " + sqle.getMessage());
			}
		}
   		
   		
		
	}

}
	
