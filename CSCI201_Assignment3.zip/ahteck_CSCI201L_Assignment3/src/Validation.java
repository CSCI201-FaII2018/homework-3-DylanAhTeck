

import java.io.IOException;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.api.services.calendar.model.Events;


/**
 * Servlet implementation class Validation
 */
@WebServlet("/Validation")
public class Validation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
    	String start_date = request.getParameter("start_date");
    	String end_date = request.getParameter("end_date");
    	String start_time = request.getParameter("start_time");
    	String end_time = request.getParameter("end_time");
    	
    	String next = "/event.jsp";
    	
    
    	
    	Event event = new Event()
    		    .setSummary(title);
    		    
    	    DateTime startDateTime = new DateTime(start_date + "T" + start_time + ":00-08:00");
    	    
    	    EventDateTime start = new EventDateTime()
        		    .setDateTime(startDateTime)
        		    .setTimeZone("America/Los_Angeles");
        		event.setStart(start);
        		
    		DateTime endDateTime = new DateTime(end_date + "T" + end_time + ":00-08:00");
    		
    		EventDateTime end = new EventDateTime()
        		    .setDateTime(endDateTime)
        		    .setTimeZone("America/Los_Angeles");
        		event.setEnd(end);


    		String calendarId = "primary";
    		
    		
    		 HttpSession session = request.getSession(false);  
   		  //False because we do not want it to create a new session if it does not exist.
   		    
   		    Calendar service = null;
   		  
   		      if(session != null){
   		          service = (Calendar) session.getAttribute("service");
   		          System.out.println("service was received: " + service);
   		          
   		      }
   		      
    		//Insert Event
   		      event = service.events().insert(calendarId, event).execute();
  	 
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		
    	try {
    		dispatch.forward(request,response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//Helper function to return month string 
	private static String getMonthForInt(int m) {
		m = m-1;
		
	    String month = "invalid";
	    DateFormatSymbols dfs = new DateFormatSymbols();
	    String[] months = dfs.getMonths();
	    if (m >= 0 && m <= 11 ) {
	        month = months[m];
	    }
	    return month;
	}

}
