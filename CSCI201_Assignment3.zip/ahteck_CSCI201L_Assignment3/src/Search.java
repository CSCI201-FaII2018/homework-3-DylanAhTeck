

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ahteck_CSCI201L_Assignment3.User;

import javax.servlet.*;

import java.sql.*;
import java.util.*;

/**
 * Servlet implementation class Search
 */
@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static Connection conn;
    private static PreparedStatement ps;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException,IOException{
    		HttpSession session = request.getSession(true);
    		
    		  String driver="com.mysql.jdbc.Driver";
    		  try {
				Class.forName(driver).newInstance();
              conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");
              
            String googleIDString = (String) session.getAttribute("googleIDString");
            
            String query = request.getParameter("query");     
            System.out.println(query);
            
            if (query == null || query == "")
            {
            
            	ps = conn.prepareStatement("SELECT * FROM UserAccounts WHERE googleIDString != ?");
            	ps.setString(1, googleIDString);
            }
            
            
            
            else {
            String sqlquery = "SELECT * FROM UserAccounts WHERE googleIDString != ? AND (username LIKE ?";
            String[] split = query.split(" ");
            
            for(int i = 1; i < split.length; i++)
            {
            	sqlquery += " OR username LIKE ?";
            }
            
            sqlquery += ")";
            
      		ps = conn.prepareStatement(sqlquery);
      		
      		ps.setString(1, googleIDString);
      		for(int i = 0; i < split.length; i++) {
      		
      			ps.setString(i+2, "%" + split[i] + "%");
      		}
      		
      		System.out.print(ps);
            }
            
            
      		ResultSet r = ps.executeQuery();
      	
      		List<User> usersList = new ArrayList<User>();
      
      		while(r.next()) {
      			User user = new User();
      			user.setName(r.getString("username"));
      			user.setImage(r.getString("imgURLString"));
      			System.out.println(r.getString("username"));
          		System.out.println(r.getString("imgURLString"));
      			usersList.add(user);
      		}
      		
      		
	   		
	   		
			
      		request.setAttribute("usersList" , usersList);
      		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/SearchResults.jsp");
  		 
  		  
      		try {
        		dispatch.forward(request,response);
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (ServletException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    		
    		
  
      		
    	
    		  } catch (InstantiationException e1) {
  				// TODO Auto-generated catch block
  				e1.printStackTrace();
  			} catch (IllegalAccessException e1) {
  				// TODO Auto-generated catch block
  				e1.printStackTrace();
  			} catch (ClassNotFoundException e1) {
  				// TODO Auto-generated catch block
  				e1.printStackTrace();
			}catch (SQLException s){
	    		System.out.println("SQL statement is not executed!");
	    		s.printStackTrace();
			}catch (Exception e){
	    		e.printStackTrace();
	    		}
	    		
    		  /*
    		  request.setAttribute("booklist",booklist); 
    		  RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/searchbook.jsp");
    		  dispatcher.forward(request, response); 
    		*/
}			

    		
}



