import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.JsonFactory;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.client.util.store.MemoryDataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;

import ahteck_CSCI201L_Assignment3.User;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.List;
import java.sql.*;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 * Servlet implementation class LogiServlet
 */
@WebServlet(name = "LoginServlet", urlPatterns = { "/LoginServlet" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
    private static Connection conn = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps = null;
	
	public static Calendar service; 
	
	public static Calendar returnCal()
	{
		return service;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			
			//Store data from Login_Page.jsp in variables (note: idTokenString not necessary in this case) 
        	String idTokenString = request.getParameter("idtoken");
        	String googleIDString = request.getParameter("ID");
        	String accessTokenString = request.getParameter("access_token");
        	String imgURLString = request.getParameter("imageURL");
        	String username = request.getParameter("name");
        	
        	final NetHttpTransport HTTP_Transport;
        	try {
				HTTP_Transport = GoogleNetHttpTransport.newTrustedTransport();
				
				//Create credential object through function
				Credential credential = getCredentials(HTTP_Transport, accessTokenString, googleIDString);

				
				
				  final com.google.api.client.json.JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
				  final String APPLICATION_NAME = "DYLAN'S SYCAMORE CALENDAR";
			  	     
			  	 
				
				 service = new Calendar.Builder(HTTP_Transport, JSON_FACTORY, credential)
			                .setApplicationName(APPLICATION_NAME)
			                .build();
				 
				 //Create session and store useful variables
				 HttpSession session = request.getSession(true);
				 
				 session.setAttribute("img", imgURLString);
				 session.setAttribute("service", service);
				 session.setAttribute("name", username);
				 session.setAttribute("googleIDString", googleIDString);
				 
				
				// List the next 10 events from the primary calendar.
			        DateTime now = new DateTime(System.currentTimeMillis());
			        Events events = service.events().list("primary")
			                .setMaxResults(10)
			                .setTimeMin(now)
			                .setOrderBy("startTime")
			                .setSingleEvents(true)
			                .execute();
			        List<Event> eventItems = events.getItems();
			        
			        //Create list of the required table columnn values
			        List<String> title = new ArrayList<String>();
			        List<String> StartDate = new ArrayList<String>();
			        List<String> StartTime = new ArrayList<String>();
			        
			        for(int i = 0; i < eventItems.size(); i++)
			        {
			        	title.add(eventItems.get(i).getSummary());
			        	DateTime start = eventItems.get(i).getStart().getDateTime();
			            if (start == null) {
			                start = eventItems.get(i).getStart().getDate();
			            }
			            String str = start.toString(); 
			            String[] DateTime = str.split("T", 2); 
			            
			            //Parse date into correct format
			            String[] parse_date = DateTime[0].split("-", 3);
			            String month = parse_date[1];
			            int monthInt = Integer.valueOf(month);  
					    month = getMonthForInt(monthInt);
			            
					    //Parse time into correct format 
					    String time = DateTime[1];
					    time = time.substring(0, 5);
					    
					   
					    DateFormat f1 = new SimpleDateFormat("HH:mm"); //HH for hour of the day (0 - 23)
					    Date d = null;
					    try {
							d = f1.parse(time);
						} catch (ParseException e) {
							e.printStackTrace();
						}
					    DateFormat f2 = new SimpleDateFormat("h:mma");
					    time = f2.format(d);
					  
			            StartDate.add(month + " " + parse_date[2] + ", " + parse_date[0]);
			            StartTime.add(time);
			        }
			        
			        
			     
			       
			        //Send to profile page
			        session.setAttribute("title", title);
			        session.setAttribute("date", StartDate);
			        session.setAttribute("time", StartTime);
				 
				 
				//Set cookie expiry to 30 mins
			       Cookie loginCookie = new Cookie("user",googleIDString);
					loginCookie.setMaxAge(30*60);
					response.addCookie(loginCookie);		        
					response.sendRedirect("PrintEvents");
					
					
				
					
					
			       			        
			} catch (GeneralSecurityException e) {
				e.printStackTrace();
			}
        	
       
        	
        	// List the next 10 events from the primary calendar.
            DateTime now = new DateTime(System.currentTimeMillis());
            Events events = service.events().list("primary")
                    .setMaxResults(10)
                    .setTimeMin(now)
                    .setOrderBy("startTime")
                    .setSingleEvents(true)
                    .execute();
            List<Event> eventItems = events.getItems();
            
            //Create list of the required table columnn values
            List<String> title = new ArrayList<String>();
            List<String> StartDate = new ArrayList<String>();
            List<String> StartTime = new ArrayList<String>();
            
            for(int i = 0; i < eventItems.size(); i++)
            {
            	title.add(eventItems.get(i).getSummary());
            	DateTime start = eventItems.get(i).getStart().getDateTime();
                if (start == null) {
                    start = eventItems.get(i).getStart().getDate();
                }
                String str = start.toString(); 
                String[] DateTime = str.split("T", 2); 
                
                //Parse date into correct format
                String[] parse_date = DateTime[0].split("-", 3);
                String month = parse_date[1];
                int monthInt = Integer.valueOf(month);  
    		    month = getMonthForInt(monthInt);
                
    		    //Parse time into correct format 
    		    String time = DateTime[1];
    		    time = time.substring(0, 5);
    		    
    		   
    		    DateFormat f1 = new SimpleDateFormat("HH:mm"); //HH for hour of the day (0 - 23)
    		    Date d = null;
    		    try {
    				d = f1.parse(time);
    			} catch (ParseException e) {
    				e.printStackTrace();
    			}
    		    DateFormat f2 = new SimpleDateFormat("h:mma");
    		    time = f2.format(d);
    		  
                StartDate.add(month + " " + parse_date[2] + ", " + parse_date[0]);
                StartTime.add(time);
            }
            
            String driver="com.mysql.jdbc.Driver";
            
        
          
            
            try{  

            Class.forName(driver).newInstance(); 

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");
            
            PreparedStatement checkAccountExists = conn.prepareStatement("SELECT 1 FROM UserAccounts WHERE googleIDString = ?");
            checkAccountExists.setString(1, googleIDString);
            ResultSet r = checkAccountExists.executeQuery();
            r = checkAccountExists.executeQuery();
            
            int n = eventItems.size(); 
            if(n > 10) n = 10;
       
            if(!r.next()) {
            	
	            try {
	            	
	          
	            ps =(PreparedStatement) conn.prepareStatement("insert into UserAccounts (idTokenString, googleIDString, accessTokenString, imgURLString, username) values(?,?,?,?,?)");
	  
	       ;
	            
	            ps.setString(1,idTokenString);  
	            ps.setString(2,googleIDString);        
	            ps.setString(3,accessTokenString);
	            ps.setString(4,imgURLString);
	            ps.setString(5,username);
	
	            ps.executeUpdate();
	         
	            ps =(PreparedStatement) conn.prepareStatement("insert into UserEvents (title, sDate, sTime, googleIDString, eventNUM) values(?,?,?,?,?)");
	            
	            for(int i = 0; i < n; i++)
	            {
	                ps.setString(1,title.get(i));  
		            ps.setString(2,StartDate.get(i));        
		            ps.setString(3,StartTime.get(i));
		            ps.setString(4, googleIDString);
		            ps.setInt(5, i);
		            ps.executeUpdate();
	            }
	            
	            System.out.println("idTokenString : " + idTokenString);
		
	            
	            ps.close();
	            
	            }catch (Exception e){  
	            	e.printStackTrace();
	            }  
            
            }
            
            else 
            	{
            	
         
      
            	
            	 PreparedStatement update = conn.prepareStatement
                ("UPDATE UserEvents SET title = ?, sDate = ?, sTime = ? WHERE googleIDString = ? AND eventNUM = ?");

            	   for(int i = 0; i < n; i++)
   	            {
   	                update.setString(1,title.get(i));  
   		            update.setString(2,StartDate.get(i));        
   		            update.setString(3,StartTime.get(i));
   		            update.setString(4, googleIDString);
   		            update.setInt(5, i);
   		            update.executeUpdate();
   	            }
            	   
            	   
            	   update.executeUpdate();
            	  
            	   
            	}
            }catch (Exception e){  
            	e.printStackTrace();
            }  
    	
    //ADDED HERE
            
        	try {
        		
         Class.forName(driver).newInstance(); 
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");
            
          
          //String googleIDString = (String) session.getAttribute("googleIDString");
           System.out.println("Trigger 1");
       	ps = conn.prepareStatement("SELECT * FROM Friends WHERE myUserID = ?");
       	ps.setString(1, googleIDString);
       	
        List<User> usersList = new ArrayList<User>();
        
 		ResultSet r = ps.executeQuery();
 		
 		while(r.next()) {
 			System.out.println("Trigger 2");

 			String follower = r.getString("friendID");
 			
 			ps = conn.prepareStatement("SELECT * FROM UserAccounts WHERE googleIDString = ?");
 			ps.setString(1, follower);
 			ResultSet rs = ps.executeQuery();
 			
 			if(rs.next()) {
 	  			User user = new User();
 	  			user.setName(rs.getString("username"));
 	  			user.setImage(rs.getString("imgURLString"));
 	  			System.out.println(rs.getString("username"));
 	      		System.out.println(rs.getString("imgURLString"));
 	  			usersList.add(user);
 			}
 		}
 	
 		
 		HttpSession session = request.getSession(true);
		session.setAttribute("usersList" , usersList);
 	
 		
 		
  		
           /*
          String query = request.getParameter("query");     
          System.out.println(query);

          
          	ps = conn.prepareStatement("SELECT * FROM UserAccounts WHERE googleIDString != ?");
          	ps.setString(1, googleIDString);
          
          
          
          

          
          
    		ResultSet r = ps.executeQuery();
    	
    		List<User> usersList = new ArrayList<User>();
    
    		while(r.next()) {
    			User user = new User();
    			user.setName(r.getString("username"));
    			user.setImage(r.getString("imgURLString"));
    			System.out.println(r.getString("username"));
        		System.out.println(r.getString("imgURLString"));
    			usersList.add(user);
    		}
    		
    		
     		
     		
    		HttpSession session = request.getSession(true);
    		session.setAttribute("usersList" , usersList);
    		//RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Home_Page.jsp");
    		 */
        	
        	/*
    		try {
      		//dispatch.forward(request,response);
  		} catch (IOException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		} catch (ServletException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
  		*/
        	} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (InstantiationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IllegalAccessException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}finally{}
        	
    		//ENDS HERE
            
	}
	
	
	
	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT, String accessTokenString, String googleIDString) throws IOException {
	       
  	  	//Declare JSON_FACTORY and SCOPES variables
  	    final com.google.api.client.json.JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
  	    final List<String> SCOPES = Collections.singletonList(CalendarScopes.CALENDAR_READONLY);
  	 
  	    
  	  //Load client secret and create object
      InputStream in = LoginServlet.class.getResourceAsStream("client_secret_170626652234-bffc12jiic333djv9o6s3u002tqkj4r7.apps.googleusercontent.com.json");
      GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));


      
      // Build flow and trigger user authorization request.
      GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
				.setAccessType("offline")
				.setDataStoreFactory(MemoryDataStoreFactory.getDefaultInstance())
				.build();
      
      //Create token
      TokenResponse token = new TokenResponse();
      token.setAccessToken(accessTokenString);
      
     //Create credential object and return 
     Credential credential = flow.createAndStoreCredential(token, googleIDString);
     return credential;
  }
 
	

	//Helper function to return month string 
	private static String getMonthForInt(int m) {
		m = m-1;
		
	    String month = "invalid";
	    DateFormatSymbols dfs = new DateFormatSymbols();
	    String[] months = dfs.getMonths();
	    if (m >= 0 && m <= 11 ) {
	        month = months[m];
	    }
	    return month;
	}
	
}



