import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ahteck_CSCI201L_Assignment3.User;

/**
 * Servlet implementation class CheckFollowing
 */
@WebServlet("/CheckFollowing")
public class CheckFollowing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckFollowing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		
		  String driver="com.mysql.jdbc.Driver";
		  Connection conn = null; //create the connection to database
		  PreparedStatement ps = null;
		  
		  try {
			Class.forName(driver).newInstance();
          conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true");
          
        String googleIDString = (String) session.getAttribute("googleIDString");
        List<User> usersList = new ArrayList<User>();
        
        String query = request.getParameter("query");     
       

        	System.out.println("Trigger 1");
        	ps = conn.prepareStatement("SELECT * FROM Friends WHERE myUserID = ?");
        	ps.setString(1, googleIDString);

  		ResultSet r = ps.executeQuery();
  		
  		while(r.next()) {
  			System.out.println("Trigger 2");

  			String follower = r.getString("friendID");
  			
  			ps = conn.prepareStatement("SELECT * FROM UserAccounts WHERE UserId = ?");
  			ps.setString(1, follower);
  			ResultSet rs = ps.executeQuery();
  			
  			
  	  			User user = new User();
  	  			user.setName(rs.getString("username"));
  	  			user.setImage(rs.getString("imgURLString"));
  	  			System.out.println(rs.getString("username"));
  	      		System.out.println(rs.getString("imgURLString"));
  	  			usersList.add(user);
  	  		
  		}
  	
  		
  
  	
  		
  		
   		
   		
  		System.out.println("Trigger 3");

  		request.setAttribute("usersList" , usersList);
  		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Home_Page.jsp");
		 
		  
  		try {
    		dispatch.forward(request,response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

  		
	
		  } catch (InstantiationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IllegalAccessException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
		}catch (SQLException s){
    		System.out.println("SQL statement is not executed!");
    		s.printStackTrace();
		}catch (Exception e){
    		e.printStackTrace();
    		}
		  
	}
    		
		/*
		int myID = (int)session.getAttribute("googleIDString");
		//int followID = Integer.parseInt(request.getParameter("follow"));
		
		ArrayList<Integer> following = new ArrayList<Integer>();
		
		String driverClassName = "com.mysql.jdbc.Driver";
   		String dbURL = "jdbc:mysql://localhost:3306/SycamoreDatabase?user=root&password=Protrek7&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
   		Connection conn = null; //create the connection to database
		Statement st = null; //executes any sql command
		PreparedStatement ps = null;
		ResultSet rs = null; //retrieve data that comes back (from select statement), a table
		
   		try {
   	   		
   			Class.forName(driverClassName);
   			conn = DriverManager.getConnection(dbURL);
   			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Friends;");
			
			boolean add = true;
			
			ArrayList<String> returnUsers = new ArrayList<String>();
	   		ArrayList<String> returnURLs = new ArrayList<String>();

			//if(followID==0) {
				while(rs.next()) {
					int user = rs.getInt("myUserID");
					if(user==myID) {
						int friend = rs.getInt("friendID");
						
						Statement s = conn.createStatement();
						ResultSet r = s.executeQuery("Select * FROM Users;");
						
						while(r.next()) {
							if(friend==r.getInt("UserID")) {
								
								returnUsers.add(r.getString("name"));
								returnURLs.add(r.getString("imgURLString"));	
														
							}
						}
						
					}
				//}
				
				session.setAttribute("returnUsers", returnUsers);
				session.setAttribute("returnURLs", returnURLs);
  
				
   				RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Home_Page.jsp");
   				
   	   	   		try {
   	   	   			dispatch.forward(request,response);
   	   	   		} catch (IOException e) {
   	   	   			// TODO Auto-generated catch block
   	   	   			e.printStackTrace();
   	   	   		} catch (ServletException e) {
   	   	   			// TODO Auto-generated catch block
   	   	   			e.printStackTrace();
   	   	   		}   				
   	   	   		
			finally {
			try {
				
				if(rs!=null) {
					rs.close();
				}
				if(st!=null) {
					st.close();
				}
				if(conn!=null) {
					conn.close();
				}
				
			}
			catch (SQLException sqle) {
				System.out.println("sqle closing streams: " + sqle.getMessage());
			}
		}
   	   	   		
	}
				
  } catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (ClassNotFoundException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}finally {}
   		
	}
	*/
}
   		
	
   		
	


